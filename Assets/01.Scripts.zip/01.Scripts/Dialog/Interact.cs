

public interface IInteractable
{
    void Interact();
}
