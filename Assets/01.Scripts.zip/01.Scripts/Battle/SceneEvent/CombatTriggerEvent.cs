using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CombatTriggerEvent : MonoBehaviour
{
    [Header("전투 정보")]
    public CombatSetupData setupData;
    
    [Header("메인 UI 루트 (씬 전환 시 숨길 것)")]
    public GameObject mainUI;
    
    private Scene _previousScene;

    public void TriggerCombat()
    {
        // 대화 컷씬 숨기기
        if (DialogueManager.Instance != null)
            DialogueManager.Instance.EndDialogue();
        
        // UI 숨기기
        if (mainUI != null) mainUI.SetActive(false);
        
        // 이전 씬 저장
        _previousScene = SceneManager.GetActiveScene();
        
        // 전투 데이터 전달
        CombatDataHolder.SetData(setupData);
        CombatDataHolder.LastTrigger = this;

        // 전투 씬 로딩
        SceneManager.LoadSceneAsync("Battle", LoadSceneMode.Additive)
                    .completed += _ =>
        {
            var battle = SceneManager.GetSceneByName("Battle");
            if (battle.IsValid())
                SceneManager.SetActiveScene(battle);
            
            CombatManager.Instance.StartCombat();
        };
    }
    
    // 전투가 끝났을 때 호출
    public void OnBattleEnd()
    {
        StartCoroutine(UnloadBattleSceneRoutine());
    }
    
    private IEnumerator UnloadBattleSceneRoutine()
    {
        // Battle 씬을 비동기로 언로드
        AsyncOperation asyncUnload = SceneManager.UnloadSceneAsync("Battle");

        // 언로드가 완료될 때까지 대기
        while (!asyncUnload.isDone)
        {
            yield return null;
        }
    
        // 이전 씬을 다시 활성 씬으로 설정
        if (_previousScene.IsValid())
        {
            SceneManager.SetActiveScene(_previousScene);
        }

        // 메인 UI 재활성화
        if (mainUI != null) mainUI.SetActive(true);

        // 대화 재개 (안전하게 호출)
        DialogueManager.Instance?.ResumeDialogue();
    
        // 모든 작업이 끝난 후 데이터 정리
        CombatDataHolder.Clear();
    }
}