public enum OwnerType
{ 
    Player,
    CaptainCat,
    SecurityDog,
    Rabbit,
    Hamster,
    Kitty
}